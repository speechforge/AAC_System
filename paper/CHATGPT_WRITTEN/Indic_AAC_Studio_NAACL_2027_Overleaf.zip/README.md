# Indic AAC Studio · NAACL 2027 System Demonstrations

Upload the ZIP as a new Overleaf project, select **XeLaTeX**, and set **main.tex** as the main file. The project uses the supplied ACL style and bibliography style. The preprint option keeps author details visible for single-blind review. The manuscript has six content pages, followed by the ethics statement and references.

A local build uses TeX Live with XeLaTeX, BibTeX, TikZ, Liberation Serif (a Times-compatible face), and Noto Serif Devanagari and Gujarati.

    latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex

The TeX under sections/ is editable. The architecture is drawn in figures/architecture.tex. The Hindi UI figure is a crop of the actual frontend running in headless Chromium. The capture routed requests to the supplied template and seed-corpus predictor code, with the frontend configured to use browser speech as the fallback. The figure provides visual evidence of the interaction and the realized text.

## Complete the red fields

| Field | Required evidence |
|---|---|
| Authors | Confirmed author order, affiliations, and contact emails |
| Demo or installation link | Working reviewer-facing URL with a complete scripted walkthrough |
| Video | Narrated or captioned screencast, no longer than 2 minutes 30 seconds |
| Repository and release | Resolvable repository URL and exact release tag or commit |
| Application license and assets | Repository license and documented redistribution terms for each released dataset, pictogram source, and reference clip |
| Privacy and AI disclosures | Deployment-specific logging, retention and voice consent, plus any additional use of generative AI in system or data development |

The track sets a six-content-page cap, single-blind review, and a 2.5-minute video cap. A live demo or downloadable installable package is required unless a stated exception applies. The ethics statement and references are outside the six-page allowance. [NAACL 2027 System Demonstrations call](https://2027.naacl.org/calls/system_demonstration/)

## Evidence supplied with this draft

| File | Manuscript use |
|---|---|
| evidence/summary.json | Scenario-level aggregate scores, paired contrasts, recovery counts, and request latency |
| evidence/prediction.json | English and Hindi top-k ranking, source-level bootstrap results, and repeated-utterance checks |
| evidence/reliability_ui.json | Scripted browser and API checks |
| evidence/env.json and evidence/config.json | Evaluated build, hardware, target checkpoint revision, and bootstrap settings |

Run **python3 tools/build_result_tables.py** to regenerate the LaTeX table data from the archived aggregates. The exact 192-scenario fixture was regenerated from the supplied generator and board and matched the SHA-256 in the recorded results. The supplied frontend and HMM source excerpts have different hashes from the evaluated copies named in the environment manifest. The UI screenshot is tied to the supplied frontend, and the tables are tied to the archived benchmark. The source bundle lacks the raw run ledger and the full prediction corpora. The archived numbers were checked for internal consistency, and the handoff below specifies what is needed to rerun the experiments.

The coding-agent prompt covers the remaining evidence and includes a screencast plan. [Verification handoff](handoff/VERIFY_DEMO_EVIDENCE.md)
